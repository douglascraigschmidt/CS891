package edu.vandy.simulator.managers.palantiri.reentrantLockHashMapSimpleSemaphore;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import edu.vandy.simulator.ReflectionHelper;
import edu.vandy.simulator.managers.palantiri.Palantir;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ReentrantLockHashMapSimpleSemaphoreMgrTest {
    // Model parameters.
    private final static int PALANTIRI_COUNT = 5;

    @Mock
    private SimpleSemaphore mSemaphoreMock;

    private ReentrantLock mLockMock;

    @InjectMocks
    private ReentrantLockHashMapSimpleSemaphoreMgr mManager;

    // In order to put mock entries in this map, it can't be a mock.
    private HashMap<Palantir, Boolean> mPalantiriMap = new HashMap<>(PALANTIRI_COUNT);

    // In order to put mock entries in this list, it can't be a mock.
    private List<Palantir> mPalantiri;

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @Before
    public void setup() throws IllegalAccessException {
        mPalantiri =
                IntStream.rangeClosed(1, PALANTIRI_COUNT)
                        .mapToObj(unused -> mock(Palantir.class))
                        .collect(Collectors.toList());
        mPalantiri.forEach(palantir -> mPalantiriMap.put(palantir, true));

        // mPalantiriMap and mPalantiri can't be mocked themselves,
        // only their contents can be mocked.
        mManager.mPalantiriMap = mPalantiriMap;
        mManager.mPalantiri = mPalantiri;

        // Handles the case where the user has declared the lock field as
        // either Lock or ReentrantLock.
        mLockMock = mock(ReentrantLock.class);
        Field field = ReflectionHelper.findFirstMatchingField(mManager, ReentrantLock.class);
        if (field != null) {
            field.set(mManager, mLockMock);
        } else {
            field = ReflectionHelper.findFirstMatchingField(mManager, Lock.class);
            field.set(mManager, mLockMock);
        }
    }

    @Test
    public void buildModel() {
        // Note that the buildModel method does not use the
        // mManager created in the @Before setup
        // method because it needs to test the real Semaphore,
        // ReentrantLock, and HashMap fields for proper initialization.
        ReentrantLockHashMapSimpleSemaphoreMgr manager =
                mock(ReentrantLockHashMapSimpleSemaphoreMgr.class);
        List<Palantir> mockPalantiri =
                IntStream.rangeClosed(1, PALANTIRI_COUNT)
                        .mapToObj(unused -> mock(Palantir.class))
                        .collect(Collectors.toList());

        when(manager.getPalantiri()).thenReturn(mockPalantiri);

        doCallRealMethod().when(manager).buildModel();

        // Call SUT method.
        manager.buildModel();

        try {
            Lock lock = ReflectionHelper.findFirstMatchingFieldValue(manager, ReentrantLock.class);
            assertNotNull(
                    "Lock field should exist and not be null.",
                    lock);
        } catch (Throwable t) {
            Lock lock = ReflectionHelper.findFirstMatchingFieldValue(manager, Lock.class);
            assertNotNull(
                    "Lock field should exist and not be null.",
                    lock);
        }

        SimpleSemaphore availablePalantiri =
                ReflectionHelper.findFirstMatchingFieldValue(manager, SimpleSemaphore.class);
        assertNotNull(
                "SimpleSemaphore field should exist and not be null",
                availablePalantiri);

        assertNotNull(
                "mPalantiriMap should not be null.",
                manager.mPalantiriMap);

        assertEquals(
                "getPalantiriMap() should contain " + PALANTIRI_COUNT + " entries.",
                PALANTIRI_COUNT,
                manager.mPalantiriMap.size());
    }

    @Test
    public void testGetSemaphore() {
        ReentrantLockHashMapSimpleSemaphoreMgr manager =
                mock(ReentrantLockHashMapSimpleSemaphoreMgr.class);
        List<Palantir> mockPalantiri =
                IntStream.rangeClosed(1, PALANTIRI_COUNT)
                        .mapToObj(unused -> mock(Palantir.class))
                        .collect(Collectors.toList());

        when(manager.getPalantiri()).thenReturn(mockPalantiri);

        doCallRealMethod().when(manager).buildModel();

        // Call SUT method.
        try {
            manager.buildModel();
        } catch (Exception e) {
            // Don't care if buildModel fails because it's only
            // called to ensure that a SimpleSemaphore field has
            // be initialized.
        }

        doCallRealMethod().when(manager).getSemaphore();
        SimpleSemaphore simpleSemaphore = manager.getSemaphore();
        assertNotNull("getSemaphore() should return a non-null SimpleSemaphore value.", simpleSemaphore);

        SimpleSemaphore availablePalantiri =
                ReflectionHelper.findFirstMatchingFieldValue(manager, SimpleSemaphore.class);
        assertSame("getSemaphore() should return the class SimpleSemaphore field value.",
                availablePalantiri, simpleSemaphore);
    }

    /**
     * Uses mManager instance created in the @Before setup method.
     */
    @Test
    public void testAcquireWithAllPalantiriAvailable() throws InterruptedException {
        Palantir palantir = mManager.acquire();

        assertNotNull("Acquire should return a non-null Palantir", palantir);
        long locked =
                mPalantiriMap.values()
                        .stream()
                        .filter(b -> !b)
                        .count();
        assertEquals("Only 1 palantir should be locked", 1, locked);

        verify(mSemaphoreMock).acquire();

        try {
            verify(mLockMock).lock();
        } catch (Throwable t) {
            verify(mLockMock).lockInterruptibly();
        }

        verify(mLockMock).unlock();
    }

    /**
     * Uses mManager instance created in the @Before setup method.
     */
    @Test
    public void testAcquireWithOnlyOnePalantiriAvailable() throws InterruptedException {
        // Lock all but on Palantir.
        lockAllPalantiri();
        Palantir unlockedPalantir = mPalantiri.get(PALANTIRI_COUNT - 1);
        unlockPalantir(unlockedPalantir);

        InOrder inOrder = inOrder(mLockMock, mSemaphoreMock);

        Palantir palantir = mManager.acquire();

        assertNotNull("Acquire should return a non-null Palantir", palantir);
        long lockedCount =
                mPalantiriMap.values()
                        .stream()
                        .filter(b -> !b)
                        .count();
        assertEquals(
                "All " + PALANTIRI_COUNT + " palantiri should be locked",
                PALANTIRI_COUNT,
                lockedCount);

        assertSame(
                "The only available Palantir should be returned",
                unlockedPalantir,
                palantir);

        verify(mSemaphoreMock).acquire();
        try {
            verify(mLockMock).lock();
        } catch (Throwable t) {
            verify(mLockMock).lockInterruptibly();
        }
        verify(mLockMock).unlock();

        inOrder.verify(mSemaphoreMock).acquire();
        try {
            inOrder.verify(mLockMock).lock();
        } catch (Throwable t) {
            inOrder.verify(mLockMock).lockInterruptibly();
        }
        inOrder.verify(mLockMock).unlock();
    }

    /**
     * Uses mManager instance created in the @Before setup method.
     */
    @Test
    public void testAcquireAllAvailablePalantiri() throws InterruptedException {
        InOrder inOrder = inOrder(mLockMock, mSemaphoreMock);

        for (int i = 1; i <= PALANTIRI_COUNT; i++) {
            Palantir palantir = mManager.acquire();
            assertNotNull("Acquire should return a non-null Palantir", palantir);

            long lockedCount =
                    mPalantiriMap.values()
                            .stream()
                            .filter(b -> !b)
                            .count();
            assertEquals(
                    i + " palantiri should be acquired (locked).",
                    i,
                    lockedCount);
        }

        verify(mSemaphoreMock, times(PALANTIRI_COUNT)).acquire();
        try {
            verify(mLockMock, times(PALANTIRI_COUNT)).lock();
        } catch (Throwable t) {
            verify(mLockMock, times(PALANTIRI_COUNT)).lockInterruptibly();
        }
        verify(mLockMock, times(PALANTIRI_COUNT)).unlock();

        inOrder.verify(mSemaphoreMock).acquire();
        try {
            inOrder.verify(mLockMock).lock();
        } catch (Throwable t) {
            inOrder.verify(mLockMock).lockInterruptibly();
        }
        inOrder.verify(mLockMock).unlock();
    }

    @Test
    public void testReleaseNullPalantir() {
        try {
            mManager.release(null);
        } catch (Exception e) {
            fail("Release should not throw an exception if a " +
                    "null Palantir is passed as a parameter.");
        }
    }

    @Test
    public void testReleaseOneAcquiredPalantir() throws InterruptedException {
        Palantir lockedPalantir = mPalantiri.get(PALANTIRI_COUNT - 1);
        lockPalantir(lockedPalantir);

        mManager.release(lockedPalantir);

        try {
            verify(mLockMock).lock();
        } catch (Throwable t) {
            verify(mLockMock).lockInterruptibly();
        }
        assertTrue(
                "Released Palantir should not be locked in HashMap.",
                mPalantiriMap.get(lockedPalantir));
    }

    @Test
    public void testReleaseAllAcquiredPalantiri() throws InterruptedException {
        lockAllPalantiri();

        mPalantiri.forEach(palantir -> mManager.release(palantir));

        InOrder inOrder = inOrder(mLockMock);

        try {
            verify(mLockMock, times(PALANTIRI_COUNT)).lock();
        } catch (Throwable t) {
            verify(mLockMock, times(PALANTIRI_COUNT)).lockInterruptibly();
        }
        verify(mLockMock, times(PALANTIRI_COUNT)).unlock();

        try {
            inOrder.verify(mLockMock).lock();
        } catch (Throwable t) {
            inOrder.verify(mLockMock).lockInterruptibly();
        }
        inOrder.verify(mLockMock).unlock();

        long count = mPalantiriMap.values().stream()
                .filter(b -> b)
                .count();
        assertEquals(
                "All " + PALANTIRI_COUNT + " Palantiri should be unlocked.",
                PALANTIRI_COUNT,
                count);
    }

    private void lockAllPalantiri() {
        for (int i = 0; i < PALANTIRI_COUNT; i++) {
            Palantir palantir = mPalantiri.get(i);
            mPalantiriMap.put(palantir, false);
        }
    }

    private void unlockPalantir(Palantir palantir) {
        mPalantiriMap.put(palantir, true);
    }

    private void lockPalantir(Palantir palantir) {
        mPalantiriMap.put(palantir, false);
    }

    private class LockCounter {
        int lock = 0;
        int lockInterruptibly = 0;
    }
}