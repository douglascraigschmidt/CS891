package edu.vandy.simulator.managers.beings.parallelStreams;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Phaser;

import edu.vandy.simulator.managers.beings.BeingManager;
import edu.vandy.simulator.utils.BlockingTask;

/**
 * This class manages the Palantiri simulation using parallel streams.
 */
public class ParallelStreamsMgr 
       extends BeingManager<BeingRunnableWithBarriers> {
    /**
     * A reusable Phaser entry barrier that ensures all background
     * threads start running at the same time.
     */
    private Phaser mEntryBarrier;

    /**
     * A single-use CountDownLatch exit barrier that ensures the
     * waiter thread doesn't finish until all the beings finish.
     */
    private CountDownLatch mExitBarrier;

    /**
     * Default constructor that's needed by the GenericPresenter
     * framework.
     */
    public ParallelStreamsMgr() {
    }

    /**
     * Resets the fields to their initial values and tells all beings
     * to reset themselves.
     * <p>
     * Override this class if the being manager implementation has
     * it's own fields or state to reset.
     */
    @Override
    public void reset() {
        super.reset();
    }

    /**
     * @return A new BeingRunnable instance
     */
    @Override
    public BeingRunnableWithBarriers newBeing() {
        return new BeingRunnableWithBarriers(this);
    }

    /**
     * This method is called to start the being gazing simulation.
     */
    @Override
    public void runSimulation() {
        // Initialize an exit barrier to ensure the waiter thread
        // doesn't finish until all the beings finish.
        // TODO -- you fill in here.
        mExitBarrier = new CountDownLatch(getBeingCount());

        // Initialize an entry barrier that ensures all background
        // threads start running at the same time.
        // TODO -- you fill in here.
        mEntryBarrier = new Phaser(1); // Use "1" to register this thread.

        // Enable all beings to start running the gazing logic, which
        // attempts to acquire a lease on a palantir and gaze into it.
        runBeingsAsync(mEntryBarrier, mExitBarrier);

        // Wait for all beings to finish gazing and then inform the UI
        // that the simulation is done.
        waitForBeingsToComplete();
    }

    /**
     * Called when a shutdown has been requested.
     */
    @Override
    public void shutdownNow() {
        // No special handling required.
    }

    /**
     * Run all Beings in a Parallel Stream, each of which attempts to
     * acquire a lease on a Palantir and gaze into it.
     */
    private void runBeingsAsync(Phaser entryBarrier,
                                CountDownLatch exitBarrier) {
        // Prepare all beings to run.
        getBeings().forEach(being ->
                            // Prepare the Being for this simulation run
                            // by passing gazing iterations and both barriers.
                            being.prepareToRun(entryBarrier, exitBarrier));

        // Create/start a new thread containing a parallel stream that
        // runs each being concurrently.
        // TODO -- you fill in here.
        new Thread(() -> {
                getBeings()
                    // Create a parallel stream.
                    .parallelStream()

                    // Run each being concurrently in the stream.
                    .forEach(BlockingTask::runInManagedBlock);
        }).start();
    }

    /**
     * Wait for all beings to finish gazing and then inform the UI
     * that the simulation is done.
     */
    private void waitForBeingsToComplete() {
        // Start a Java thread that waits for all beings to finish
        // gazing and then call simulationComplete() to inform the UI
        // that the simulation is done.

        // TODO -- you fill in here.
        try {
            // Let all the beings start gazing.
            // TODO -- you fill in here.
            mEntryBarrier.arriveAndAwaitAdvance();

            // Wait for all beings to stop gazing.
            // TODO -- you fill in here.
            mExitBarrier.await();
        } catch (Exception e) {
            // If we get interrupted while waiting, report the
            // error to the simulator so that it will return a
            // request to error this simulation.
            error(e);
        }
    }
}
