package edu.vandy.simulator.managers.palantiri.stampedLockSimpleSemaphore;

/**
 * This class defines a counting semaphore with "fair" semantics that
 * are implemented using Java built-in monitor object features.
 */
class SimpleSemaphore {
    /**
     * Define a count of the number of available permits.
     */
    // TODO - you fill in here.  Ensure that this data member will
    // ensure its values aren't cached by multiple Threads..
    volatile int mPermits;

    /**
     * Constructor initialize the data members.
     */
    public SimpleSemaphore(int permits) {
        // TODO -- you fill in here. 
        mPermits = permits;
    }

    /**
     * Acquire one permit from the semaphore in a manner that can be
     * interrupted.
     */
    public void acquire() throws InterruptedException {
        // TODO -- you fill in here.
        synchronized (this) {

            while (mPermits <= 0)
                wait();

            mPermits--;
        }
    }

    /**
     * Acquire one permit from the semaphore in a manner that cannot
     * be interrupted.  If an interrupt occurs while this method is
     * running make sure to set the interrupt state when the thread
     * returns from this method.
     */
    public void acquireUninterruptibly() {
        // TODO -- you fill in here.
        boolean interrupted = false;

        synchronized (this) {

            while (mPermits <= 0)
                try {
                    wait();
                } catch (InterruptedException e) {
                    interrupted = true;
                }

            mPermits--;
        }

        if (interrupted)
            // Propagate the interrupt if we were interrupted.
            Thread.currentThread().interrupt();
    }

    /**
     * Return one permit to the semaphore.
     */
    public void release() {
        // TODO -- you fill in here.
        synchronized (this) {
            mPermits++;

            // Optimization.
            if (mPermits > 0) {
                notify();
            }
        }
    }

    /**
     * Returns the current number of permits.
     */
    protected int availablePermits() {
        // TODO -- you fill in here.  
        return mPermits;
    }
}
