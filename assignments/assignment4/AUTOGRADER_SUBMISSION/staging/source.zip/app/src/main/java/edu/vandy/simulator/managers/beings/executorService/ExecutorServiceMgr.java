package edu.vandy.simulator.managers.beings.executorService;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import edu.vandy.simulator.Controller;
import edu.vandy.simulator.managers.beings.BeingManager;

import static java.util.stream.Collectors.toList;

/**
 * This BeingManager implementation uses the Java ExecutorService to
 * create a pool of Java threads that run the being simulations.
 */
public class ExecutorServiceMgr
        extends BeingManager<BeingCallable> {
    /**
     * Used for Android debugging.
     */
    private final static String TAG =
            ExecutorServiceMgr.class.getName();

    /**
     * The list of futures to BeingCallables that are running
     * concurrently in the ExecutorService's thread pool.
     */
    // TODO -- you fill in here.
    private List<Future<BeingCallable>> mFutureList;

    /**
     * The ExecutorService contains a fixed pool of threads.
     */
    // TODO -- you fill in here.
    private ExecutorService mExecutor;

    /**
     * Default constructor.
     */
    public ExecutorServiceMgr() {
    }

    /**
     * Resets the fields to their initial values
     * and tells all beings to reset themselves.
     */
    @Override
    public void reset() {
        super.reset();
    }

    /**
     * Abstract method that BeingManagers implement to return a new
     * BeingCallable instance.
     *
     * @return A new typed Being instance.
     */
    @Override
    public BeingCallable newBeing() {
        // Return a new BeingCallable instance.
        // TODO -- you fill in here, replacing null with the
        // appropriate code.
        return new BeingCallable(this);
    }

    /**
     * This entry point method is called by the Simulator framework to
     * start the being gazing simulation.
     **/
    @Override
    public void runSimulation() {
        // Call a method that uses the ExecutorService to create/start
        // a pool of threads that represent the beings in this
        // simulation.
        // TODO -- you fill in here.
        beginBeingThreadPool();

        // Call a method that waits for all futures to complete.
        // TODO -- you fill in here.
        awaitCompletionOfFutures();

        // Call this classes ExecutorServiceMgr shutdownNow() method
        // to cleanly shutdown the executor service.
        // TODO -- you fill in here.
        shutdownNow();
    }

    /**
     * Use the ExecutorService to create/start a pool of threads that
     * represent the beings in this simulation.
     */
    void beginBeingThreadPool() {
        // All STUDENTS:
        // Create an ExecutorService instance that contains a
        // fixed-size pool of threads, with one thread for each being.
        // Call the BeingManager.getBeings() method to iterate through
        // the BeingCallables, submit each BeingCallable to the
        // ExecutorService, and add it to the list of BeingCallable
        // futures.
        // TODO -- you fill in here.

        // GRADUATE STUDENTS:
        // Use a Java 8 stream to submit each BeingCallable and
        // collect the results into the list of BeingCallable futures.
        // Undergraduate students are free to use a Java 8 stream, but
        // it's not required.

        // Create an ExecutorService instance that contains a
        // fixed-size pool of threads, with one thread for each being.
        mExecutor = Executors.newFixedThreadPool(getBeings().size());

        // Store the results in mFutureList.
        mFutureList = getBeings()
                // Convert the list into a stream.
                .stream()

                // Run each BeingCallable concurrently in the
                // ExecutorService thread pool.
                .map(mExecutor::submit)

                // Trigger intermediate processing and return a list of
                // futures.
                .collect(toList());
    }

    /**
     * Wait for all the futures to complete.
     */
    void awaitCompletionOfFutures() {
        // All STUDENTS:
        // Use a for-each loop to wait for all futures to complete.
        // Tell the Controller log when a simulation completes
        // normally.  If an exception is thrown, however, then tell
        // the Controller log which exception was caught.

        // GRADUATE STUDENTS:
        // Use a Java 8 stream (including a map() aggregate operation)
        // instead of a for-each loop to process the futures.
        // Undergraduate students are free to use a Java 8 stream, but
        // it's not required.

        // TODO -- you fill in here.

        // Keeps track of how many beings were processed.
        long beingCount = mFutureList
                // Convert the list into a stream.
                .stream()

                // Get the result of the future and print it properly.
                .map(future -> {
                    BeingCallable being = null;
                    try {
                        being = future.get();
                        Controller.log(TAG +
                                ": awaitCompletionOfFutures: "
                                + being
                                + " completed normally.");
                    } catch (Exception e) {
                        Controller.log(TAG +
                                ": awaitCompletionOfFutures: "
                                + being
                                + " caught exception: "
                                + e);
                    }
                    return being;
                })

                // Count the number of beings processed.
                .count();

        /*
        // Loop through each future in the list.
        for (Future<BeingCallable> future : mFutureList) {
            BeingCallable being = null;
            try {
                being = future.get();
                Controller.log(TAG +
                               ": awaitCompletionOfFutures: "
                               + being 
                               + " completed normally.");
            } catch (Exception e) {
                Controller.log(TAG +
                                   ": awaitCompletionOfFutures: "
                                   + being 
                                   + " caught exception: " 
                                   + e);
            }
            beingCount++;
        }
        */

        // Print the number of beings that were processed.
        Controller.log(TAG +
                ": awaitCompletionOfFutures: exiting with "
                + getRunningBeingCount()
                + "/"
                + beingCount
                + " running beings.");
    }

    /**
     * Called to terminate the executor service. This method should
     * only return after all threads have been terminated and all
     * resources cleaned up.
     */
    @Override
    public void shutdownNow() {
        Controller.log(TAG + ": shutdownNow: entered");

        // Cancel all the outstanding BeingCallables via their
        // futures, but only if they aren't already done or already
        // canceled.
        // TODO -- you fill in here.
        mFutureList.forEach(future -> {
            // Cancel the computation associated with the future.
            if (!future.isDone() && !future.isCancelled()) {
                future.cancel(true);
            }
        });

        // Shutdown the executor *now*.
        // TODO -- you fill in here.
        mExecutor.shutdownNow();

        Controller.log(TAG + ": shutdownNow: exited with "
                + getRunningBeingCount() + "/"
                + getBeingCount() + " running beings.");
    }
}
