package edu.vandy.simulator.managers.palantiri.stampedLockSimpleSemaphore;

import android.util.Log;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.locks.StampedLock;
import java.util.function.Function;

import edu.vandy.simulator.managers.palantiri.Palantir;
import edu.vandy.simulator.managers.palantiri.PalantiriManager;

import static java.util.stream.Collectors.toMap;

/**
 * Defines a mechanism that mediates concurrent access to a fixed
 * number of available Palantiri.  This class uses a SimpleSemaphore,
 * a HashMap, and a StampedLock to mediate concurrent access to the
 * Palantiri.  This class implements a variant of the "Pooling"
 * pattern (kircher-schwanninger.de/michael/publications/Pooling.pdf).
 */
public class StampedLockSimpleSemaphoreMgr
       extends PalantiriManager {
    /**
     * Debugging tag used by the Android logger.
     */
    private final static String TAG =
            StampedLockSimpleSemaphoreMgr.class.getSimpleName();

    /**
     * A counting semaphore that limits concurrent access to the fixed
     * number of available palantiri managed by the
     * StampedLockSimpleSemaphoreMgr.
     */
    SimpleSemaphore mAvailablePalantiri;

    /**
     * A map that associates the @a Palantiri key to the @a boolean
     * values that keep track of whether the key is available.
     */
    Map<Palantir, Boolean> mPalantiriMap;

    /**
     * A StampedLock synchronizer that protects the Palantiri state.
     */
    // TODO -- you fill in here.  
    private StampedLock mStampedLock;

    /**
     * Zero parameter constructor required for Factory creation.
     */
    public StampedLockSimpleSemaphoreMgr() {
    }

    /**
     * Resets the fields to their initial values and tells all beings
     * to reset themselves.
     * <p>
     * Override this class if the being manager implementation has
     * it's own fields or state to reset.
     */
    @Override
    public void reset() {
        super.reset();

        // Reset all map entries back to true for the next run.
        mPalantiriMap.entrySet().forEach(entry -> entry.setValue(true));

        // Since semaphores can't be reset, we have no choice but
        // to create a new SimpleSemaphore for the next run.
        mAvailablePalantiri =
            new SimpleSemaphore(mPalantiriMap.size());
    }

    /**
     * Called by super class to build the Palantiri model.
     */
    @Override
    public void buildModel() {
        // Create a new HashMap, iterate through the List of Palantiri
        // and initialize each key in the HashMap with "true" to
        // indicate it's available, and initialize the Semaphore to
        // use a "fair" implementation that mediates concurrent access
        // to the given Palantiri.

        // Use the getPalantiri() to get a list of Palantiri and
        // initialize each key in the mPalantiriMap with "true" to
        // indicate it's available.  Grad students should use a Java 8
        // stream to initialize mPalantiriMap, whereas ugrad students
        // can implement without using a Java 8 stream.
        // TODO -- you fill in here.
        mPalantiriMap = getPalantiri()
            // Convert the list of palantiri into a stream.
            .stream()

            // Collect results into a HashMap where the keys are the
            // palantiri and all the values are true.
            .collect(toMap(Function.identity(),
                           p -> true));

        // Initialize the Semaphore to use a "fair" implementation
        // that mediates concurrent access to the given Palantiri.
        // TODO -- you fill in here.
        mAvailablePalantiri =
            new SimpleSemaphore(mPalantiriMap.size());

        // Initialize the StampedLock.
        // TODO -- you fill in here.
        mStampedLock = new StampedLock();
    }

    /**
     * Get a palantir, blocking until one is available.
     *
     * This method should never return a null Palantir. It may,
     * however, throw a InterruptedException if a shutdown is being
     * processed while a thread is waiting for a Palantir.
     */
    @Override
    @NotNull
    public
    Palantir acquire() throws CancellationException {
        // Acquire the SimpleSemaphore interruptibly and then use an
        // Iterator to iterate through the HashMap in a thread-safe
        // manner to find the first key in the HashMap whose value is
        // "true" (which indicates it's available for use).  Replace
        // the value of this key with "false" to indicate the Palantir
        // isn't available and then return that palantir to the
        // client.
        // 
        // This implementation should demonstrate StampedLock's
        // support for upgrading a readLock to a writeLock.  You'll
        // need to use an Iterator instead of a for-each loop so that
        // you can restart your search at the beginning of the HashMap
        // if you're unable to atomically upgrade the readlock to a
        // writelock.  This code is tricky, so please carefully read
        // the StampedLock "upgrade" example that's described at
        // docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/StampedLock.html.

        // TODO -- you fill in here.  

        // Needs to be declared outside the try block so that it is
        // accessible in the finally clause.
        long stamp = -1;

        // Perform all operations in a try catch so that we can ensure
        // the integrity of this manager's state even if interrupted
        // by a cancellation exception.
        try {
            // Acquire semaphore allowing for the possibility of being
            // interrupted by a shutdown.
            mAvailablePalantiri.acquire();

            // Start out with a readLock.
            stamp = mStampedLock.readLock();

            // Iterate through HashMap, with readLock initially held.
            Iterator<Map.Entry<Palantir, Boolean>> entries =
                mPalantiriMap.entrySet().iterator();

            while (entries.hasNext()) {
                // Get the next entry in the HashMap.
                Map.Entry<Palantir, Boolean> entry = entries.next();

                // Find the first key in the HashMap whose value is
                // "true," which indicates it's available for use.
                if (entry.getValue()) {
                    // Attempt to upgrade to a writeLock.
                    long writeStamp =
                        mStampedLock.tryConvertToWriteLock(stamp);

                    // If writeLock upgrade worked set the value in
                    // the HashMap since the critical section is
                    // protected from concurrent access.
                    if (writeStamp != 0) {
                        stamp = writeStamp;

                        // Check to ensure entry is still available.
                        if (entry.getValue()) {
                            // Get palantir with writeLock held.
                            Palantir palantir = entry.getKey();

                            // Replace value with "false" to indicate
                            // the Palantir's not available.
                            entry.setValue(false);

                            // Return the palantir.
                            return palantir;
                        } else
                            // If it's no longer available restart
                            // search at beginning of HashMap.
                            entries = mPalantiriMap.entrySet().iterator();
                    }
                    // Otherwise, fall back to using writeLock.
                    else {
                        // Release the readLock.
                        mStampedLock.unlockRead(stamp);

                        // Acquire a writeLock, which may block.
                        stamp = mStampedLock.writeLock();

                        // Restart at the beginning of the HashMap since
                        // its state may have changed after the readLock
                        // was released and before writeLock was acquired.
                        entries = mPalantiriMap.entrySet().iterator();
                    }
                }
            }
        } catch (InterruptedException e) {
            // Wrap InterruptedException in a CancellationException
            // and throw.
            throw new CancellationException("StampedLockSimpleSemaphoreMgr was interrupted");
        } finally {
            // Unlock either the writeLock or the readLock, depending
            // on the value of stamp.
            if (stamp != -1) {
                mStampedLock.unlock(stamp);
            }
        }

        // This method either succeeds by returning a Palantir, or
        // fails if interrupted by a shutdown.  In ether case,
        // reaching this line should not be possible.
        throw new IllegalStateException("This is not possible");
    }

    /**
     * Returns the designated @code palantir to the StampedLockPalantiriManager
     * so that it's available for other Threads to use.
     */
    @Override
    public void release(final Palantir palantir) {
        // Put the "true" value back into HashMap for the palantir key
        // in a thread-safe manner using a write lock and release the
        // SimpleSemaphore if all works properly.
        // TODO -- you fill in here.

        // Do a simple sanity check!
        if (palantir != null) {
            // This flag is used to determine whether or not to
            // release the semaphore.
            boolean callRelease = false;

            // Acquire a writeLock.
            long stamp = mStampedLock.writeLock();

            try {
                // Put "true" value back into HashMap for the palantir
                // key, which returns the boolean associated with the
                // palantir.
                if (!mPalantiriMap.put(palantir, true))
                    callRelease = true;
            } finally {
                // Release the writeLock.
                mStampedLock.unlockWrite(stamp);
                // released.
                if (callRelease) {
                    // Release the semaphore if the @palantir parameter
                    // was previously "false".
                    mAvailablePalantiri.release();
                }
            }

        }
    }

    /**
     * Called when the simulation is being shutdown to allow model
     * components the opportunity to and release resources and to
     * reset field values.
     */
    @Override
    public void shutdownNow() {
        Log.d(TAG, "shutdownNow: called.");
    }

    /**
     * Only used for regression testing.
     *
     * @return The number of available permits on the semaphore.
     */
    @Override
    protected int availablePermits() {
        return mAvailablePalantiri.availablePermits();
    }
}
