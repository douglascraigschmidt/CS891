package edu.vandy.simulator.managers.palantiri.concurrentMapFairSemaphore;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Implements a fair semaphore using the Specific Notification pattern
 * (www.dre.vanderbilt.edu/~schmidt/PDF/specific-notification.pdf)
 * using ReentrantLock/ConditionObject.  Graduate students should
 * implement this class.
 */
public class FairSemaphoreCO
        implements FairSemaphore {
    /**
     * Debugging tag used by the Android logger.
     */
    private final static String TAG =
            FairSemaphore.class.getSimpleName();
    /**
     * Define a monitor lock (using a ReentrantLock) to protect critical sections.
     */
    // TODO -- you fill in here
    private final Lock mLock;
    /**
     * Define a LinkedList "WaitQueue" that keeps track of the waiters in a FIFO
     * List to ensure "fair" semantics.
     */
    // TODO -- you fill in here.
    private final LinkedList<Waiter> mWaitQueue;
    /**
     * Define a count of the number of available permits.
     */
    // TODO -- you fill in here.  Make sure that this field will ensure
    // its values aren't cached by multiple threads..
    private volatile int mAvailablePermits;

    /**
     * For mocking only.
     */
    protected FairSemaphoreCO() {
        mLock = null;
        mWaitQueue = null;
    }

    /**
     * Initialize the fields in the class.
     */
    public FairSemaphoreCO(int availablePermits) {
        // TODO -- you fill in here.
        mAvailablePermits = availablePermits;

        // Creates the LinkedList of wait nodes.
        mWaitQueue = new LinkedList<>();

        // Initialize the lock using "fair" semantics.
        mLock = new ReentrantLock();
    }

    /**
     * Acquire one permit from the semaphore in a manner that cannot
     * be interrupted.
     */
    @Override
    public void acquireUninterruptibly() {
        // TODO -- you fill in here, using a loop to ignore InterruptedExceptions.

        boolean interrupted = false;

        for (; ; ) {
            try {
                acquire();
                break;
            } catch (InterruptedException e) {
                // Keep looping if an interrupt occurs.
                interrupted = true;
            }
        }

        if (interrupted) {
            // Reset the interrupt flag if we were interrupted.
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Acquire one permit from the semaphore in a manner that can be
     * interrupted.
     */
    @Override
    public void acquire() throws InterruptedException {
        // Bail out quickly if we've been interrupted.
        if (Thread.interrupted()) {
            throw new InterruptedException();

            // Try to get a permit without blocking.
        } else if (!tryToGetPermit()) {
            // Block until a permit is available.
            waitForPermit();
        }
    }

    /**
     * Handle the case where we can get a permit without blocking.
     *
     * @return Returns true if the permit was obtained, else false.
     * If the return value is true then monitor lock has been
     * unlocked, otherwise it's still locked.
     */
    protected boolean tryToGetPermit() {
        // TODO -- first try the "fast path" where the method doesn't
        // need to block if there are no waiters in the queue or if
        // there are permits available.

        // Synchronize access via mLock to prevent race conditions.
        mLock.lock();

        // We don't need to wait if there are no waiters in the
        // queue or if there are permits available.
        if (tryToGetPermitUnlocked()) {
            mLock.unlock();
            return true;
        } else {
            return false;
        }
    }

    /**
     * Factors out code that checks to see if a permit can be obtained
     * without blocking.  This method assumes the monitor lock
     * ("intrinsic lock") is held.
     *
     * @return Returns true if the permit was obtained, else false.
     */
    protected boolean tryToGetPermitUnlocked() {
        // We must wait if there are already conditions in the queue
        // or if there are no permits available.
        // TODO -- you fill in here.
        if (mWaitQueue.isEmpty() && mAvailablePermits > 0) {
            // No need to wait, so decrement and return.
            //noinspection NonAtomicOperationOnVolatileField
            --mAvailablePermits;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Constructs a new Waiter (required for test mocking).
     *
     * @return A new Waiter instance
     */
    protected Waiter createWaiter() {
        return new Waiter();
    }

    /**
     * Handle the case where we need to block since there are already
     * waiters in the queue or no permits are available.  If this
     * method is called the monitor lock is held.
     */
    protected void waitForPermit() throws InterruptedException {
        // Call createWaiter helper method to allocate a new Waiter that
        // acts as the "specific-notification lock".
        final Waiter waiter = createWaiter();

        // TODO -- implement "fair" semaphore acquire semantics using
        // the Specific Notification pattern.

        try {
            // Acquire the waiter lock so we can call await() on its
            // condition below.
            waiter.mLock.lock();

            try {
                // Add waiter to the FIFO queue since we must wait.
                mWaitQueue.add(waiter);
            } finally {
                // Always unlock mLock here to prevent deadlock.
                mLock.unlock();
            }

            // The following call to await() isn't called with mLock
            // held to prevent deadlock.
            try {
                // Block until we're notified via signal().  Keep
                // looping until mReleased is true to deal with
                // spurious wakeups (which are very unlikely..).
                while (!waiter.mReleased) {
                    waiter.mCondition.await();
                }

                // If we were waiting let the thread calling release()
                // decrement the permit count since if do it here
                // we'll end up in a race with other threads who might
                // have entered the critical section above.
            } catch (InterruptedException e) {
                System.out.println(TAG
                        + ": In waitForPermit(), where thread "
                        + Thread.currentThread().getId()
                        + " got a InterruptedException");

                // Acquire the lock and try and remove ourselves from
                // the queue.
                mLock.lock();
                try {
                    // If waiter is not on queue then another thread
                    // released it already, so give back the permit.
                    if (!mWaitQueue.remove(waiter)) {
                        release();
                    }

                    // Rethrow the exception.
                    throw e;
                } finally {
                    // Always release the lock.
                    mLock.unlock();
                }
            }
        } finally {
            // Always release the lock.
            waiter.mLock.unlock();
        }
    }

    /**
     * Return one permit to the semaphore.
     */
    @Override
    public void release() {
        // TODO -- implement "fair" semaphore release semantics using
        // the Specific Notification pattern.

        Waiter nextWaiter;
        mLock.lock();

        try {
            // Check if another thread is waiting on a permit by
            // trying to get the next waiter (in FIFO order) and
            // removing that waiter from the queue if it exists.
            if ((nextWaiter = mWaitQueue.poll()) == null) {
                // Release a permit since there are no waiters.
                //noinspection NonAtomicOperationOnVolatileField
                ++mAvailablePermits;

                // We're done.
                return;
            }
        } finally {
            // Always release the lock.
            mLock.unlock();
        }

        // Since there's another waiter thread then synchronize on
        // this waiter so we can notify it that a permit is available.
        nextWaiter.mLock.lock();
        try {
            // Update nextWaiter's release flag and signal next thread
            // blocked in acquire() that a permit is available for it.
            nextWaiter.mReleased = true;
            nextWaiter.mCondition.signal();
        } finally {
            nextWaiter.mLock.unlock();
        }
    }

    /**
     * @return The number of available permits.
     */
    @Override
    public int availablePermits() {
        // @@ TODO -- you fill in here replacing 0 with the right
        // value.
        return mAvailablePermits;
    }

    /**
     * Define a class that can be used in the "WaitQueue" to wait for
     * a specific thread to be notified.
     */
    static class Waiter {
        /**
         * A lock used to synchronize access to the condition below.
         */
        // TODO -- you fill in here.
        final Lock mLock;
        /**
         * A condition that's used to wait in FIFO order.
         */
        // TODO -- you fill in here.
        final Condition mCondition;
        /**
         * Keeps track of whether the Waiter was released or not to
         * detected and handle "spurious wakeups".
         */
        boolean mReleased = false;

        /**
         * Private constructor (only available to static create() method)
         * initializes the fields.
         */
        Waiter() {
            // TODO -- you fill in here to initialize the lock and condition fields.
            mLock = new ReentrantLock();
            mCondition = mLock.newCondition();
        }
    }
}

