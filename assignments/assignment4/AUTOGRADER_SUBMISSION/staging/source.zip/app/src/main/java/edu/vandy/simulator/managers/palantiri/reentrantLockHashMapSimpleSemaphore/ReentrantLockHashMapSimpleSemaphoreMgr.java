package edu.vandy.simulator.managers.palantiri.reentrantLockHashMapSimpleSemaphore;

import android.util.Log;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Function;

import edu.vandy.simulator.managers.palantiri.Palantir;
import edu.vandy.simulator.managers.palantiri.PalantiriManager;

import static java.util.stream.Collectors.toMap;

/**
 * Defines a mechanism that mediates concurrent access to a fixed
 * number of available Palantiri.  This class uses a HashMap, a
 * SimpleSemaphore, and a ReentrantLock to mediate concurrent access
 * to the Palantiri.  This class implements a variant of the "Pooling"
 * pattern (kircher-schwanninger.de/michael/publications/Pooling.pdf).
 */
public class ReentrantLockHashMapSimpleSemaphoreMgr extends PalantiriManager {
    /**
     * Debugging tag used by the Android logger.
     */
    protected final static String TAG =
            ReentrantLockHashMapSimpleSemaphoreMgr.class.getSimpleName();
    /**
     * A map that associates the Palantir key to the Boolean values to
     * keep track of whether the key is available.
     */
    HashMap<Palantir, Boolean> mPalantiriMap;

    /**
     * A counting SimpleSemaphore that limits concurrent access to the
     * fixed number of available palantiri managed by the
     * PalantiriManager.
     */
    // TODO -- you fill in here.
    SimpleSemaphore mAvailablePalantiri;

    /**
     * A Lock used to protect critical sections involving the HashMap.
     */
    // TODO -- you fill in here.
    Lock mLock;

    /**
     * Resets the fields to their initial values
     * and tells all beings to reset themselves.
     * <p>
     * Override this class if the being manager
     * implementation has it's own fields or
     * state to reset.
     */
    @Override
    public void reset() {
        super.reset();
    }

    /**
     * @return The semaphore. 
     */
    SimpleSemaphore getSemaphore() {
        // TODO -- you fill in here, replacing null with the
        // appropriate field.
        return mAvailablePalantiri;
    }
     
    /**
     * Implementations should setup and initialize class field
     * required for the Palantiri management strategy. All Palantiri
     * will have already been created by this super class. The list of
     * Palantiri can be accessed via the getPalantiri() method and the
     * count via getPalantirCount().
     */
    @Override
    protected void buildModel() {
        // ALL STUDENTS:
        // Create a new HashMap, iterate through the List of Palantiri
        // and initialize each key in the HashMap with "true" to
        // indicate it's available, initialize the Semaphore to use a
        // "fair" implementation that mediates concurrent access to
        // the given Palantiri, and initialize the ReentrantLock to
        // use "unfair" semantics.

        // GRADUATE STUDENTS:
        // Use a Java 8 stream to get a list of Palantiri and
        // initialize each key in the mPalantiriMap with "true" to
        // indicate it's available

        // Undergraduate students are free to use a Java 8 stream, but
        // it's not required.

        // TODO -- you fill in here.

        // Create a new HashMap.
        mPalantiriMap = new HashMap<>();

        // Use the getPalantiri() to get a list of Palantiri and
        // initialize each key in the mPalantiriMap with "true" to
        // indicate it's available.
        // TODO -- you fill in here.
//        mPalantiriMap = getPalantiri()
//                    // Convert the list of palantiri into a stream.
//                    .stream()
//
//            // Collect results into a HashMap where the keys are the
//            // palantiri and all the values are true.
//                    .collect(toMap(Function.identity(),
//                           p -> true));

        mPalantiriMap
                .putAll(getPalantiri()
                        // Convert the list of palantiri into a stream.
                        .stream()

                        // Collect results into a HashMap where the keys
                        // are the palantiri and all the values are true.
                        .collect(toMap(Function.identity(),
                                p -> true)));

        // Initialize the SimpleSemaphore with a "fair" implementation
        // that mediates concurrent access to the given Palantiri.
        // TODO -- you fill in here.
        mAvailablePalantiri =
                new SimpleSemaphore(mPalantiriMap.size());

        // Initialize a new ReentrantLock.
        // TODO -- you fill in here.
        mLock = new ReentrantLock();
    }

    /**
     * Get a Palantir from the PalantiriManager, blocking until one is
     * available.
     *
     * @return The first available Palantir.
     */
    @Override
    @NotNull
    protected Palantir acquire() throws InterruptedException {
        // ALL STUDENTS:
        // Acquire the SimpleSemaphore interruptibly and then find the
        // first key in the HashMap whose value is "true" (which
        // indicates it's available for use) in a thread-safe manner
        // (i.e., using the ReentrantLock properly).  Replace the
        // value of this key with "false" to indicate the Palantir
        // isn't available and return that palantir to the client.

        // GRADUATE STUDENTS:
        // Use a Java 8 stream find the key in the HashMap whose value
        // is "true" and replace the key with "false".

        // Undergraduate students are free to use a Java 8 stream, but
        // it's not required.

        // TODO -- you fill in here.

        // Acquire the Semaphore interruptibly.
        mAvailablePalantiri.acquire();

        // Serialize the following actions in an interruptible manner to
        // ensure thread-safety.
        mLock.lockInterruptibly();
        try {
            Palantir p = mPalantiriMap
                // Get the entrySet for the map.
                .entrySet()

                // Convert the entrySet into a stream.
                .stream()

                // Only consider palantiri whose status is available.
                .filter(Map.Entry::getValue)

                // Set palantir status to busy.
                .map(entry -> {
                        // Replace the value with "false" to indicate
                        // the Palantir is not available.
                        entry.setValue(false);
                        return entry.getKey();
                    })

                // Return the first palantir that was available.
                .findFirst()

                // Use the null value if there's no match (this
                // shouldn't happen).
                .orElse(null);

            // Return the palantir if it's non-null.
            if (p != null)
                return p;
        } finally {
            // Always release the lock.
            mLock.unlock();
        }

        // This invariant should always hold for all acquire()
        // implementations if implemented correctly.  That is the
        // purpose of enforcing the @NotNull along with the
        // CancellationException, i.e., it is clear that all
        // implementations should either be successful (if implemented
        // correctly) and return a Palantir, or fail because of
        // cancellation.
        throw new IllegalStateException("This method should either return a valid " 
                                        + "Palantir or throw a InterruptedException. " 
                                        + "In either case, this statement should not be reached.");
    }

    /**
     * Releases the {@code palantir} so that it's available
     * for for other threads to use.
     *
     * @param palantir The palantir to release back to
     *                 the Palantir pool.
     */
    @Override
    protected void release(Palantir palantir) {
        // Put the "true" value back into HashMap for the palantir key
        // in a thread-safe manner and release the SimpleSemaphore if
        // all works properly.
        // TODO -- you fill in here.

        // Do a simple sanity check!
        if (palantir != null) {
            // This flag is used to determine whether or not to
            // release the semaphore.
            boolean callRelease = false;

            // Hold the lock for the duration of this call so it
            // operates in a thread-safe manner.
            mLock.lock();
            try {
                // Put the "true" value back into HashMap for the
                // palantir key, which also atomically returns the
                // boolean associated with the palantir.
                final boolean values =
                    mPalantiriMap.put(palantir, true);
                if (!values)
                    callRelease = true;
            } finally {
                // Always release the lock.
                mLock.unlock();
            }

            // Check to see whether the semaphore needs to be
            // released.
            if (callRelease)
                // Release the semaphore if the @palantir parameter
                // was previously "false".
                mAvailablePalantiri.release();
        }
    }

    /**
     * This method is just intended for use by the regression tests,
     * not by applications.
     *
     * @return the number of available permits on the semaphore.
     */
    @Override
    protected int availablePermits() {
        return getSemaphore().availablePermits();
    }

    /**
     * Called when the simulation is being shutdown to allow model
     * components the opportunity to and release resources and to
     * reset field values.  The Beings will have already have been
     * shutdown by the base class before calling this method.
     */
    @Override
    public void shutdownNow() {
        Log.d(TAG, "shutdownNow: called.");
    }
}
