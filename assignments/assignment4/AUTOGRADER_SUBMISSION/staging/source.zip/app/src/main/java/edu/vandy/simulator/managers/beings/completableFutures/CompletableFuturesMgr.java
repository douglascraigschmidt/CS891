package edu.vandy.simulator.managers.beings.completableFutures;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import edu.vandy.simulator.Controller;
import edu.vandy.simulator.managers.beings.BeingManager;
import edu.vandy.simulator.utils.StreamsUtils;

import static java.util.stream.Collectors.toList;

/**
 * Use JAva 8 completable futures to run the being gazing logic.
 */
public class CompletableFuturesMgr
        extends BeingManager<SimpleBeingRunnable> {
    /**
     * Logging tag.
     */
    private static final String TAG = "CompletableFuturesMgr";

    /**
     * Defines a pool of threads that allow beings to gaze at a fixed
     * number of palantiri.
     */
    private ExecutorService mExecutor;

    /**
     * A ThreadFactory object that spawns an appropriately named
     * thread for each being.
     */
    private ThreadFactory mThreadFactory =
            // TODO -- you fill in here by replacing "return null"
            // with a ThreadFactory implementation that uses a Java 8
            // lambda expression to create a new Thread each time it's
            // called.
            (runnable) -> {
                // Create a new thread.
                Thread thr = new Thread(runnable);

                thr.setUncaughtExceptionHandler
                        ((thread, throwable) ->
                                // Call error handler which will route
                                // this call back down to this class's
                                // shutdownNow() method.
                                error(throwable));
                return thr;
            };

    /**
     * Default constructor.
     */
    public CompletableFuturesMgr() {
    }

    /**
     * Abstract method that BeingManagers implement to return a new
     * concrete Being instance. Not that design will automatically
     * create the correct being for each manager and therefore
     * managers should NOT create the beings directory themselves;
     * they already exist in an array that can be accessed by a simple
     * getBeings() call.
     *
     * @return A new typed Being instance.
     */
    @Override
    public SimpleBeingRunnable newBeing() {
        return new SimpleBeingRunnable(this);
    }

    /**
     * This method is called when the user asks to start the
     * simulation in the context of the main UI Thread.
     **/
    @Override
    public void runSimulation() {
        // Store a list of futures to asynchronous gazing operations
        // that are created via a stream pipeline that that generates
        // beingCount asynchronous calls each of which creates a new
        // BeingRunnable and runs it.

        // Create a ThreadPoolExecutor that runs all the Being tasks.
        // TODO -- you fill in here.
        mExecutor =
                Executors.newFixedThreadPool(getBeingCount(),
                        mThreadFactory);

        // Return a CompletableFuture that can be used to wait for all
        // the asynchronous operations to complete.
        // TODO -- you fill in here.
        CompletableFuture<List<Void>> future =
                runBeingThreadsAsync(getBeingCount());

        // When the CompletableFuture has completed then call
        // mView.get().done() to inform the View layer that the
        // simulation is done. Also, explicitly call the executor
        // error method to ensure that any pooled threads are released
        // for garbage collection.
        // TODO -- you fill in here.
        future.thenAccept(v -> {
            // Shutdown the executor service.
            mExecutor.shutdownNow();
        }).exceptionally(throwable -> {
            System.out.println(TAG + ": CompletableFutures caught an exception: " + throwable);
            return null;
        });

        // Calling method expects this caller to block until the
        // simulation has completed or was cancelled.
        future.join();

        Controller.log(TAG + ": runSimulation: ended.");
    }

    /**
     * Create and run {@code beingCount} beings asynchronously.
     *
     * @param beingCount Number of beings in the simulation run
     * @return A CompletableFuture that can be used to wait for all
     * the asynchronous operations to complete
     */
    private CompletableFuture<List<Void>> runBeingThreadsAsync(int beingCount) {
        // Store a list of futures to asynchronous gazing operations
        // created via a stream pipeline that generates "beingCount"
        // asynchronous calls each of which creates a new
        // BeingRunnable and runs it.

        // TODO -- you fill in here.

        List<CompletableFuture<Void>> futures =
                // Generate beingCount asynchronous calls that use the
                // beings that were previously created by calls newBeing()
                // when the model was first built.
                getBeings()
                        // Convert the list into a stream.
                        .stream()

                        // Asynchronously run each being.
                        .map(being -> CompletableFuture.runAsync(being, mExecutor))

                        // Return a list of CompletableFutures.
                        .collect(toList());

        // Return a CompletableFuture that can be used to wait for all
        // the asynchronous operations to complete.

        // TODO -- you fill in here to replace null with the
        // appropriate call.
        return StreamsUtils.joinAll(futures);
    }

    /**
     * Called to run to error the simulation and should only return
     * after all threads have been terminated and all resources
     * cleaned up.
     */
    @Override
    public void shutdownNow() {
        synchronized (this) {
            // Shutdown the ExecutorService thread pool now.
            // TODO -- you fill in here.
            if (mExecutor != null) {
                mExecutor.shutdownNow();
            }
        }
    }
}
