package edu.vandy.simulator.managers.palantiri.concurrentMapFairSemaphore;

import java.util.LinkedList;

/**
 * Implements a fair semaphore using the Specific Notification pattern
 * (www.dre.vanderbilt.edu/~schmidt/PDF/specific-notification.pdf)
 * using the Java built-in monitor object.  Undergraduate students
 * should implement this class.
 */
public class FairSemaphoreMO
        implements FairSemaphore {
    /**
     * Debugging tag used by the Android logger.
     */
    protected final static String TAG =
            FairSemaphoreMO.class.getSimpleName();

    /**
     * Define a count of the number of available permits.
     */
    // TODO -- you fill in here.  Make sure that this field will ensure
    // its values aren't cached by multiple threads..
    protected volatile int mAvailablePermits;
    /**
     * Define a LinkedList "WaitQueue" that keeps track of the waiters in a FIFO
     * List to ensure "fair" semantics.
     */
    // TODO -- you fill in here.
    protected LinkedList<Waiter> mWaitQueue;

    /**
     * For mocking only.
     */
    protected FairSemaphoreMO() {
    }

    /**
     * Initialize the fields in the class.
     */
    public FairSemaphoreMO(int availablePermits) {
        // TODO -- you fill in here.
        mAvailablePermits = availablePermits;

        // Creates the LinkedList of wait nodes.
        mWaitQueue = new LinkedList<>();
    }

    /**
     * Acquire one permit from the semaphore in a manner that cannot
     * be interrupted.
     */
    @Override
    public void acquireUninterruptibly() {
        // TODO -- you fill in here, using a loop to ignore
        // InterruptedExceptions.

        boolean interrupted = false;

        for (; ; ) {
            try {
                acquire();
                break;
            } catch (InterruptedException e) {
                // Keep looping if an interrupt occurs.
                interrupted = true;
            }
        }

        if (interrupted) {
            // Reset the interrupt flag if we were interrupted.
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Acquire one permit from the semaphore in a manner that can
     * be interrupted.
     */
    @Override
    public void acquire() throws InterruptedException {
        // Bail out quickly if we've been interrupted.
        if (Thread.interrupted()) {
            throw new InterruptedException();
            // Try to get a permit without blocking.
        } else if (!tryToGetPermit()) {
            // Block until a permit is available.
            waitForPermit();
        }
    }

    /**
     * Handle the case where we can get a permit without blocking.
     *
     * @return Returns true if the permit was obtained, else false.
     */
    protected boolean tryToGetPermit() {
        // TODO -- first try the "fast path" where the method doesn't
        // need to block if the queue is empty and permits are
        // available.

        // Synchronize access via the monitor lock to protect this
        // object's state from race conditions.
        synchronized (this) {
            // Try to get the permit.
            return tryToGetPermitUnlocked();
        }
    }

    /**
     * Factors out code that checks to see if a permit can be obtained
     * without blocking.  This method assumes the monitor lock
     * ("intrinsic lock") is held.
     *
     * @return Returns true if the permit was obtained, else false.
     */
    protected boolean tryToGetPermitUnlocked() {
        // We don't need to wait if the queue is empty and
        // permits are available.
        // TODO -- you fill in here.
        if (mWaitQueue.isEmpty() && mAvailablePermits > 0) {
            // No need to wait, so decrement and return.
            //noinspection NonAtomicOperationOnVolatileField
            --mAvailablePermits;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Constructs a new Waiter (required for test mocking).
     *
     * @return A new Waiter instance
     */
    protected Waiter createWaiter() {
        return new Waiter();
    }

    /**
     * Handle the case where we need to block since there are already
     * waiters in the queue or no permits are available.
     */
    protected void waitForPermit() throws InterruptedException {
        // Call createWaiter helper method to allocate a new Waiter that
        // acts as the "specific-notification lock".
        final Waiter waiter = createWaiter();

        // TODO -- implement "fair" semaphore acquire semantics using
        // the Specific Notification pattern.

        // Synchronize on object so we can call wait() on it below.
        //noinspection SynchronizationOnLocalVariableOrMethodParameter
        synchronized (waiter) {
            // Since we must wait add our thread to the FIFO queue.
            synchronized (this) {
                // Try to get the permit again since release() may
                // have been called between the earlier call to
                // tryToGetPermit() and now.
                if (tryToGetPermitUnlocked()) {
                    return;
                } else {
                    mWaitQueue.add(waiter);
                }
            }

            // The following call to wait() isn't called on waiter
            // with "this" lock held to prevent deadlock.
            try {
                // Block until we're notified via signal().  Keep
                // looping until mReleased is true to deal with
                // spurious wakeups (which are very unlikely..).
                while (!waiter.mReleased) {
                    waiter.wait();
                }

                // If we were waiting let the thread calling release()
                // decrement the permit count for us since if we try to
                // do it here we'll end up in a race with other
                // threads who might have entered the critical section
                // above.
            } catch (InterruptedException e) {
                System.out.println(TAG
                        + ": In waitForPermit(), where thread "
                        + Thread.currentThread().getId()
                        + " got a InterruptedException");

                // Try and remove ourselves from the queue.
                synchronized (this) {
                    // If we're not on the queue, then someone
                    // released us, so give back the permit.
                    if (!mWaitQueue.remove(waiter)) {
                        release();
                    }
                }

                // Rethrow the exception.
                throw e;
            }
        }
    }

    /**
     * Return one permit to the semaphore.
     */
    @Override
    public void release() {
        // TODO -- implement "fair" semaphore release semantics
        // using the Specific Notification pattern.

        Waiter nextWaiter;
        synchronized (this) {
            // Check if another thread is waiting on a permit by
            // trying to get the next waiter (in FIFO order) and
            // removing that waiter from the queue if it exists.
            if ((nextWaiter = mWaitQueue.poll()) == null) {
                // Release a permit since there are no waiters.
                mAvailablePermits++;

                // Return since we're done.
                return;
            }

            // If there's another waiter thread then synchronize on
            // this waiter to notify it that a permit's available.
            //noinspection SynchronizationOnLocalVariableOrMethodParameter
            synchronized (nextWaiter) {
                // Set nextWaiter's flag and notify next thread
                // blocked in acquire() that a permit's available.
                nextWaiter.mReleased = true;
                nextWaiter.notify();
            }
        }
    }

    /**
     * @return The number of available permits.
     */
    @Override
    public int availablePermits() {
        // @@ TODO -- you fill in here replacing 0 with the right
        // value.
        return mAvailablePermits;
    }

    /**
     * Define a class that can be used in the "WaitQueue" to wait for
     * a specific thread to be notified.
     */
    protected static class Waiter {
        /**
         * Keeps track of whether the Waiter was released or not to
         * detected and handle "spurious wakeups".
         */
        boolean mReleased = false;

        /**
         * Constructor used for mocking.
         */
        Waiter() {
        }
    }
}
