package edu.vandy.simulator.managers.beings.parallelStreams;

import android.util.Log;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Phaser;

import edu.vandy.simulator.managers.beings.Being;
import edu.vandy.simulator.Controller;
import edu.vandy.simulator.managers.beings.BeingManager;
import edu.vandy.simulator.managers.palantiri.Palantir;

/**
 * This class implements the gazing logic of a Thread.
 */
public class BeingRunnableWithBarriers
       extends Being
       implements Runnable {
    /**
     * Logging tag.
     */
    private static final String TAG = "BeingRunnableWithBarriers";

    /**
     * A Phaser entry barrier that ensures all background threads
     * start running at the same time.
     */
    private Phaser mEntryBarrier;

    /**
     * A CountDownLatch exit barrier that ensures the waiter thread
     * doesn't finish until all the BeingAsyncTasks finish.
     */
    private CountDownLatch mExitBarrier;

    /**
     * Constructor initializes the field.
     *
     * @param manager The controlling BeingManager instance.
     */
    BeingRunnableWithBarriers(BeingManager manager) {
        // Call super constructor passing the manager.
        super(manager);
    }

    /**
     * Called to set exit and entry barriers instances prior to
     * running this being.
     *
     * @param entryBarrier A Phaser used to synchronize the start of all beings
     * @param exitBarrier  A CountDownLatch used by the simulator to wait for all
     *                     beings to complete or error
     */
    void prepareToRun(Phaser entryBarrier,
                      CountDownLatch exitBarrier) {
        // Save parameters.
        mEntryBarrier = entryBarrier;
        mExitBarrier = exitBarrier;

        // TODO -- you fill in here.
        // Register ourselves with the Phaser so we're included in the
        // set of registered parties.
        mEntryBarrier.register();
    }

    /**
     * Run the loop that performs the Being gazing logic.
     */
    @Override
    public void run() {
        try {
            // Don't start gazing until all BeingAsyncTasks are ready to run.
            // TODO -- you fill in here.
            mEntryBarrier.arriveAndAwaitAdvance();

            // Try to gaze at a palantir the designated number of times.
            runGazingSimulation(mManager.getGazingIterations());
        } catch (Exception e) {
            Controller.log(
                    "Exception "
                            + e
                            + " caught in Being "
                            + getId());
            // Call error handler which will record the
            // error and also notify any interested parties
            // about the error event.
            error(e);
        }
    }

    /**
     * Perform the specified number of gazing operations.
     *
     * @param gazingIterations The number of gazing operations.
     */
    public void runGazingSimulation(int gazingIterations) {
        // Call super class to handle the gazing iterations.
        super.runGazingSimulation(gazingIterations);

        // Register completion by decrementing the exit barrier count.
        mExitBarrier.countDown();
    }

    /**
     * Perform a single gazing operation.
     */
    @Override
    protected void acquirePalantirAndGaze() {
        // Get a palantir from the BeingManager by calling the
        // appropriate base class helper method - this call will block
        // if there are no available palantiri (if a concurrency error
        // occurs in the assignment implementation, null is returned
        // and this being should immediately call Being.error(), which
        // throws an IllegalStateException).  Then gaze at the
        // palantir for this being (which blocks for a random period
        // of time).  Finally, release the palantir for this being via
        // a call to the appropriate base class helper method.
        // TODO -- you fill in here.
        Palantir palantir = acquirePalantir();

        if (palantir != null) {
            try {
                // Gaze into the palantir acquired by this being
                // (which blocks for a random period of time).  May
                // throw CancellationException if the being has been
                // requested to shutdown.
                palantir.gaze(this);
            } finally {
                // Always release the palantir for this being using
                // the base class helper method.
                releasePalantir(palantir);
            }
        } else {
            error("Unable to acquire palantir");
        }
    }
}
