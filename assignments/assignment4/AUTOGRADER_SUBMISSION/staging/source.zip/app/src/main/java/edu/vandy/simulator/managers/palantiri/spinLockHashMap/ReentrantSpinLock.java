package edu.vandy.simulator.managers.palantiri.spinLockHashMap;

import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * This class emulates a "compare and swap"-style spin lock with
 * recursive semantics.
 */
class ReentrantSpinLock 
      implements CancellableLock {
    /**
     * Define an AtomicReference that's used as the basis for an
     * atomic compare-and-swap.  The default state of the spinlock
     * should be "unlocked".
     */
    // TODO -- you fill in here.
    public AtomicReference<Thread> mOwner =
        new AtomicReference<>();
 
    /**
     * Count the number of times the owner thread has recursively
     * acquired the lock.
     */
    // TODO -- you fill in here.
    public int mRecursionCount;

    /**
     * Acquire the lock only if it is free at the time of invocation.
     * Acquire the lock if it is available and returns immediately
     * with the value true. If the lock is not available then this
     * method will return immediately with the value false.
     */
    @Override
    public boolean tryLock() {
        // Try to set mOwner's value to the thread (true), which
        // succeeds iff its current value is null (false).
        // TODO -- you fill in here, replacing false with the proper
        // code.
        return mOwner.compareAndSet(null, Thread.currentThread());
    }

    /**
     * Acquire the lock. If the lock is not available then the current
     * thread becomes disabled for thread scheduling purposes and lies
     * dormant until the lock has been acquired.
     *
     * @param isCancelled Supplier that is called to see if the attempt
     *                    to lock should be abandoned due to a pending
     *                    shutdown operation.
     * @throws CancellationException Thrown only if a pending shutdown
     * operation is has been detected by calling the isCancelled supplier.
     */
    @Override
    public void lock(Supplier<Boolean> isCancelled)
        throws CancellationException {
        // If the current thread owns the lock simply increment the
        // recursion count.  Otherwise, loop trying to set mOwner's
        // value to the current thread reference, which succeeds iff
        // its current value is null.  Each iteration should also
        // check if a shutdown has been requested and if so throw a
        // cancellation exception.  
        // TODO -- you fill in here.

        // Store the current thread, which is guaranteed to be unique.
        Thread currentThread = Thread.currentThread();

        // Check to see if we're the current owner.
        if (currentThread == mOwner.get()) { 
            // Simply increment the recursion count and return.
            mRecursionCount++;
            return; 
        }

        // Try to set mOwner's value to the thread (true), which
        // succeeds iff its current value is null (false).
        while (!tryLock()) {
            // Check if a shutdown has been requested and if so throw
            // a cancellation exception.
            if (isCancelled.get()) 
                throw new CancellationException("SpinLock cancelled.");

            // Yield the thread to allow another thread to run.
            Thread.yield();
        } 
    }

    /**
     * Release the lock.
     */
    @Override
    public void unlock() {
        // If the current owner is trying to unlock then simply
        // decrement the recursion count if it's > 0.  Otherwise,
        // atomically release the lock that's currently held by
        // mOwner.

        // TODO -- you fill in here.

        // Store the current thread, which is guaranteed to be unique.
        Thread currentThread = Thread.currentThread();

        // Check to see if we're the current owner.
        if (currentThread == mOwner.get()) { 
            if (mRecursionCount != 0)
                // Simply decrement the recursion count.
                mRecursionCount--;
            else
                // Set mOwner's value to null (false), which
                // atomically releases the lock that's currently held.
                mOwner.set(null);
        }
    }
}
